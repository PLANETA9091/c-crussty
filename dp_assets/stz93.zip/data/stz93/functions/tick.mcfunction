# STZ-93 tick driver: волна каждые 40t × 4 волны
execute if score $phase stz93 matches 1 if score $t stz93 matches 1 run function stz93:wave0_0
execute if score $phase stz93 matches 1 if score $t stz93 matches 2 run function stz93:wave0_1
execute if score $phase stz93 matches 1 if score $t stz93 matches 41 run function stz93:wave1_0
execute if score $phase stz93 matches 1 if score $t stz93 matches 42 run function stz93:wave1_1
execute if score $phase stz93 matches 1 if score $t stz93 matches 81 run function stz93:wave2_0
execute if score $phase stz93 matches 1 if score $t stz93 matches 82 run function stz93:wave2_1
execute if score $phase stz93 matches 1 if score $t stz93 matches 121 run function stz93:wave3_0
execute if score $phase stz93 matches 1 if score $t stz93 matches 122 run function stz93:wave3_1
execute if score $phase stz93 matches 1 run scoreboard players add $t stz93 1
