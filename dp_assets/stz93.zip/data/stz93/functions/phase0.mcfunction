# STZ-93 weak-chunk entity-storm (Paper#13783): 4 far markers
forceload add 1000000 1000000
forceload add -1000000 1000000
forceload add 1000000 -1000000
forceload add -1000000 -1000000
scoreboard players set $phase stz93 1
schedule function stz93:wave0 40t
