scoreboard objectives add stz93 dummy
scoreboard players set $phase stz93 0
scoreboard players set $t stz93 0
schedule function stz93:phase0 1t
