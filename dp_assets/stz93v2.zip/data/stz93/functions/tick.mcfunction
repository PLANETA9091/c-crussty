# STZ-93 v2: 16 колец r{2,6,..,62} x 4096, волна каждые 10t (t=42..192 <= [40,200])
execute if score $phase stz93 matches 1 if score $t stz93 matches 42 run function stz93:ring0
execute if score $phase stz93 matches 1 if score $t stz93 matches 52 run function stz93:ring1
execute if score $phase stz93 matches 1 if score $t stz93 matches 62 run function stz93:ring2
execute if score $phase stz93 matches 1 if score $t stz93 matches 72 run function stz93:ring3
execute if score $phase stz93 matches 1 if score $t stz93 matches 82 run function stz93:ring4
execute if score $phase stz93 matches 1 if score $t stz93 matches 92 run function stz93:ring5
execute if score $phase stz93 matches 1 if score $t stz93 matches 102 run function stz93:ring6
execute if score $phase stz93 matches 1 if score $t stz93 matches 112 run function stz93:ring7
execute if score $phase stz93 matches 1 if score $t stz93 matches 122 run function stz93:ring8
execute if score $phase stz93 matches 1 if score $t stz93 matches 132 run function stz93:ring9
execute if score $phase stz93 matches 1 if score $t stz93 matches 142 run function stz93:ring10
execute if score $phase stz93 matches 1 if score $t stz93 matches 152 run function stz93:ring11
execute if score $phase stz93 matches 1 if score $t stz93 matches 162 run function stz93:ring12
execute if score $phase stz93 matches 1 if score $t stz93 matches 172 run function stz93:ring13
execute if score $phase stz93 matches 1 if score $t stz93 matches 182 run function stz93:ring14
execute if score $phase stz93 matches 1 if score $t stz93 matches 192 run function stz93:ring15
execute if score $phase stz93 matches 1 if score $t stz93 matches 193 run scoreboard players set $phase stz93 0
execute if score $phase stz93 matches 1 run scoreboard players add $t stz93 1
