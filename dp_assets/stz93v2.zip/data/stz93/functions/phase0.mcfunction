# STZ-93 v2 weak-chunk entity-storm (Paper#13783): 4 far markers
forceload add 1000000 1000000
forceload add -1000000 1000000
forceload add 1000000 -1000000
forceload add -1000000 -1000000
scoreboard players set $phase stz93 1
