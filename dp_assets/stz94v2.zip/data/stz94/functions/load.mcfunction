schedule function stz94:build 1t
